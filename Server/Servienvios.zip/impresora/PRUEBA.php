<?php

define('FPDF_FONTPATH', 'font/');
require('cellpdf.php');


//CREACION DE LA CONEXION A LA BASE DE DATOS
// Configura los datos de tu cuenta
include('../Login/config.php');


// Conectar a la base de datos
$conexion=mysql_connect ($dbhost, $dbusername, $dbuserpass);
          mysql_select_db($dbname) or die('No se puede seleccionar la base de datos');


//REALIZAMOS LA CONSULTA
$result=mysql_query("SELECT * FROM guias",$conexion)or die(mysql_error());
$numero_filas = mysql_num_rows($result);

$pdf=new CellPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','',8);


while($datatmp = mysql_fetch_assoc($result)) {

	//DESTINATARIO.	

$pdf->VCell(15,40,utf8_decode('Señor(a):')."\n".$datatmp['name_rec']."\n".$datatmp['dir_rec']."\n".$datatmp['city_rec'],0,0,'D');
$pdf->Cell(50,50,utf8_decode('Señor(a):')."\n".$datatmp['name_rec']."\n".$datatmp['dir_rec']."\n".$datatmp['city_rec']."\n"."\n"."\n"."\n"
.$datatmp['name_desp']."\n".$datatmp['dir_derp']."\n".$datatmp['city_desp']."\n"
."\n".'                                '.$datatmp['id_guide'],0,0,'L');     
$pdf->Cell(20,50,$datatmp['consecutivo']."\n"."\n"."\n"."\n"."\n".$datatmp['heigth']." Grs"."\n".$datatmp['presio'],0,1,'R');
	
	
 }
 
//$pdf->RotatedImage('circle.png', 85, 60, 40, 16, 45);
$pdf->Output();

?>